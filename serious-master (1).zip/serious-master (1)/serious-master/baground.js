

document.addEventListener('DOMContentLoaded', () => {
    const themeToggleButton = document.getElementById('theme-toggle');

    // Check if dark mode is already enabled
    if (document.body.classList.contains('dark-mode')) {
        themeToggleButton.textContent = '☀️'; // Set button to sun icon if dark mode is active
    } else {
        themeToggleButton.textContent = '🌙'; // Set button to moon icon if dark mode is not active
    }

    themeToggleButton.addEventListener('click', () => {
        document.body.classList.toggle('dark-mode');
        
        // Change the icon based on the current theme
        if (document.body.classList.contains('dark-mode')) {
            themeToggleButton.textContent = '☀️'; // Sun icon for light mode
        } else {
            themeToggleButton.textContent = '🌙'; // Moon icon for dark mode
        }
    });
});


// $('.menu-btn').click(function(){
//     $('.navbar .menu').toggleClass("active");
//     $('.menu-btn').toggleClass("active");
// });